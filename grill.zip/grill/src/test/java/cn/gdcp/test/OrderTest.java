package cn.gdcp.test;

public class OrderTest {

    public static void main(String[] args) {
        byte i = 1;
        System.out.println(i);

        i += 1;
        System.out.println(i);
    }
}
